//找元素
function $(obj) {
    if (typeof obj === 'function') {
        return window.onload = obj;
    } else if (typeof obj === 'string') {
        return document.getElementById(obj);
    } else if (typeof obj === 'object') {
        return obj;
    }
}
//获取样式
function getStyle(obj, attr) {
    return obj.currentStyle ? obj.currentStyle[attr] :
        getComputedStyle(obj)[attr];
}

//div运动
/*
 * obj,目标
 * attr,属性
 * dir,当前点
 *  target,目标点
 *  time,过度时间
 *   endFn 回调函数
 * */
function doMove(obj, attr, dir, target, time, endFn) {
    //判断dir为正数还是负数(当前>目标点 为负小于为正
    dir = parseInt(getStyle(obj, attr)) < target ? dir : -dir;
    clearInterval(obj.timerDo);
    obj.timerDo = setInterval(function() {
        var speed = parseInt(getStyle(obj, attr)) + dir; //dir 每次移动的距离
        //判断当dir大于0向前小于0向后
        if (speed > target && dir > 0 || speed < target && dir < 0) {
            speed = target;
        }
        //关闭定时器
        if (speed == target) {
            clearInterval(obj.timerDo);
            //添加一个回调函数
            endFn && endFn();
        }

        obj.style[attr] = speed + 'px'; //步长
    }, time);

}
// //透明度运动
function opacityFn(obj, attr, dir, target, time, endFn) {
    clearInterval(obj.timer);
    //获取透明度
    _opacity = getStyle(obj, attr);
    //判断透明度的值
    dir = _opacity < target ? dir : -dir;
    obj.timer = setInterval(function() {
        var opacity = parseFloat(getStyle(obj, attr)) + dir;
        obj.style[attr] = opacity;
        if (opacity == target) {
            clearInterval(obj.timer);
            endFn && endFn();
        }
    }, time);

}


//抖动
function shake(obj, attr, endFn) {
    if (obj.onff)
        return;

    var pos = parseInt(getStyle(obj, attr));

    var arr = []; // 20, -20, 18, -18 ..... 0
    var num = 0;
    var timer = null;
    var onff = true;

    for (var i = 20; i > 0; i -= 2) {
        arr.push(i, -i);
    }
    arr.push(0);

    clearInterval(obj.shake);
    obj.shake = setInterval(function() {
        obj.style[attr] = pos + arr[num] + 'px';
        num++;
        if (num === arr.length) {
            clearInterval(obj.shake);
            obj.onff = false;
            endFn && endFn();
        }
    }, 50);
}
//滚动缓冲函数
function moveLeft(obj, old, now) {
    clearInterval(obj.timer);
    obj.timer = setInterval(function() {
        //设置缓冲时间
        var ispeed = (now - old) / 10;
        ispeed = ispeed > 0 ? Math.ceil(ispeed) : Math.floor(ispeed);
        if (now == old) {
            clearInterval(obj.timer);
        } else {
            old = ispeed + old;
            obj.style.left = old + 'px';
        }
    }, 30);

}

//渐入
function fadeIn(obj) {
    var iCurr = getStyle(obj, 'opacity');
    if (iCurr == 1) {
        return false;
    }
    var value = 0;
    clearInterval(obj.timer);
    obj.timer = setInterval(function() {
        var iSpeed = 5;
        if (value == 100) {
            clearInterval(obj.timer);
        } else {
            value += iSpeed;
            obj.style.opacity = value / 100;
            obj.style.filter = 'alpha(opacity=' + value + ')';
        }
    }, 60);
}
//渐出
function fadeOut(obj) {
    var iCurr = getStyle(obj, 'opacity');
    if (iCurr == 1) {
        return false;
    }
    var value = 100;
    clearInterval(obj.timer);
    obj.timer = setInterval(function() {
        var iSpeed = -5;
        if (value == 0) {
            clearInterval(obj.timer);
        } else {
            value += iSpeed;
            obj.style.opacity = value / 100;
            obj.style.filter = 'alpha(opacity=' + value + ')';
        }
    }, 60);
}