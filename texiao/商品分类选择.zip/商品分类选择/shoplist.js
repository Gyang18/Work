//商品数据列表 

var shopsList = [{
        imgUrl: 'img/lisImgs/1.jpg',
        size: '4.0-4.5英寸',
        system: 'ios',
        www: '联通3G',
        name: '苹果',
        volume: 100000,
        price: 5000
    },
    {
        imgUrl: 'img/lisImgs/2.jpg',
        size: '4.0-4.5英寸',
        system: 'ios',
        www: '双卡单4G',
        name: '苹果',
        volume: 100,
        price: 50000
    },
    {
        imgUrl: 'img/lisImgs/3.jpg',
        size: '4.6-4.9英寸',
        system: 'ios',
        www: '双卡单4G',
        name: '苹果',
        volume: 30,
        price: 50080
    },
    {
        imgUrl: 'img/lisImgs/4.jpg',
        size: '4.6-4.9英寸',
        system: 'android',
        www: '联通3G',
        name: '小米',
        volume: 1020,
        price: 50400
    },
    {
        imgUrl: 'img/lisImgs/5.jpg',
        size: '4.0-4.5英寸',
        system: 'android',
        www: '双卡单4G',
        name: '小米',
        volume: 1040,
        price: 54000
    },
    {
        imgUrl: 'img/lisImgs/6.jpg',
        size: '4.6-4.9英寸',
        system: 'android',
        www: '双卡单4G',
        name: '小米',
        volume: 1004,
        price: 50040
    },
    {
        imgUrl: 'img/lisImgs/7.jpg',
        size: '4.6-4.9英寸',
        system: 'android',
        www: '双卡单4G',
        name: '魅族',
        volume: 1050,
        price: 50040
    },
    {
        imgUrl: 'img/lisImgs/8.jpg',
        size: '5.0-5.5英寸',
        system: 'android',
        www: '双卡双4G',
        name: '魅族',
        volume: 1050,
        price: 50050
    },
    {
        imgUrl: 'img/lisImgs/9.jpg',
        size: '5.0-5.5英寸',
        system: 'android',
        www: '双卡双4G',
        name: '三星',
        volume: 1060,
        price: 5040
    },
    {
        imgUrl: 'img/lisImgs/10.jpg',
        size: '4.6-4.9英寸',
        system: 'android',
        www: '双卡单4G',
        name: '三星',
        volume: 1080,
        price: 50490
    },
    {
        imgUrl: 'img/lisImgs/11.jpg',
        size: '4.6-4.9英寸',
        system: 'android',
        www: '联通4G',
        name: '三星',
        volume: 20000,
        price: 50490
    },
    {
        imgUrl: 'img/lisImgs/12.jpg',
        size: '4.6-4.9英寸',
        system: 'android',
        www: '联通4G',
        name: '锤子',
        volume: 22000,
        price: 50490
    },
    {
        imgUrl: 'img/lisImgs/13.jpg',
        size: '5.0-5.5英寸',
        system: 'android',
        www: '双卡单4G',
        name: '锤子',
        volume: 10088,
        price: 50490
    },
    {
        imgUrl: 'img/lisImgs/15.jpg',
        size: '5.0-5.5英寸',
        system: 'android',
        www: '双卡双4G',
        name: '锤子',
        volume: 10088,
        price: 50490
    }

]